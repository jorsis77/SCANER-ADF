sta biblioteca hace referencia a WIA 2.0 , que est� disponible de forma predeterminada en Vista y superior. 

Esto funciona para Windows XP SP1 en adelante pero necesita instalar Windows� Image Acquisition Automation Library v2.0 Tambi�n puede necesitar ejecutar: 
> regsvr32.exe wiaaut.dll