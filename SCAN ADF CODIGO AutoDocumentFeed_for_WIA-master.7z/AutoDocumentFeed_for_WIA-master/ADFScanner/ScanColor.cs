﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ADFScanner
{
    public enum ScanColor : int
    {
        Color = 1,
        Gray = 2,
        BlackWhite = 4
    }
}
